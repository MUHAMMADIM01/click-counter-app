import React, { useState } from 'react';

function App() {
  const [count, setCount] = useState(0);
  const threshold = 10;

  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>Click Counter</h1>
      <h2>{count}</h2>
      <button onClick={() => setCount(count + 1)}>Increase</button>
      <button onClick={() => setCount(count > 0 ? count - 1 : 0)}>Decrease</button>
      {count >= threshold && <p>You've reached the limit!</p>}
    </div>
  );
}

export default App;